export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyDFCuFsXqy8PfbUm4MT2W9hO9tNNo-_6To",
        authDomain: "hiringapplication-56f57.firebaseapp.com",
        projectId: "hiringapplication-56f57",
        storageBucket: "hiringapplication-56f57.appspot.com",
        messagingSenderId: "515312643924",
        appId: "1:515312643924:web:4ee3c26907338830ae62c1"
    },
    fireDatabase: 'https://hiringapplication-56f57-default-rtdb.europe-west1.firebasedatabase.app/'
}
