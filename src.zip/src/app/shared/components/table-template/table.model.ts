
export interface TableInfo {
    name: string;
    hasSort: boolean;
    bodyVarName: string;
}