export interface Notifications {
    id: string;
    name: string;
    email: string;
    jobId: string;
    jobName: string;
    timeSended: string;
  }